var app = {
        
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    onDeviceReady: function() {
        document.getElementById("btnInserir").addEventListener("click",app.inserir);  
    },

    inserir: function(){
        var db = firebase.firestore();

        let cnome = document.getElementById("nameInput").value;
        let ctelefone = document.getElementById("phoneInput").value;
        let corigem = document.getElementById("origemInput").value;
        let cdata_contato = document.getElementById("dateInput").value;
        let cobservacao = document.getElementById("observacoes").value;

        db.collection("cadastro").add({
			data_contato: cdata_contato,
            nome: cnome,
			observacao: cobservacao,
            telefone: ctelefone,
            origem: corigem
        })
        .then((docRef) => {
            console.log("Document written with ID: ", docRef.id);
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });

    }  
};

app.initialize();